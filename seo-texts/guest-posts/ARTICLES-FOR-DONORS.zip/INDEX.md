# Статьи для доноров

Все прошли механический гейт: объём, стоп-слова, инженерные детекторы, белый
список ссылок и их позиции, целостность тегов, разрешённая разметка. Рядом с
каждой статьёй .meta.json с TITLE, DESCRIPTION и анонсом для площадки.

| Донор | Статья | Наши ссылки | Знаков |
|---|---|---|---|
| autopulse05.ru | vozduh-dlya-pokraski-avto | enger-air.ru/catalog/osushiteli_vozdukha/adsorbtsionnye_osus | 10834 |
| factories.by | kompressornaya-dlya-ceha | prokompressor.ru/catalog/kompressornye-stantsii-szhatogo-voz<br>prokompressor.ru/catalog/kompressornye-stantsii-szhatogo-voz | 9353 |
| ftimes.ru | kondensat-dorozhe-chem-kazhetsya | enger-air.ru/catalog/osushiteli_vozdukha/refrizheratornye_os<br>berg-compressor.com/catalog/vintovye-kompressory | 9271 |
| gazetagavrilovka.ru | kompressor-zimoy-v-neotaplivaemom | remeza-kompressor.ru/catalog/kompressory<br>enger-air.ru/catalog/vintovye_kompressory<br>dali-kompressor.ru/catalog/vintovye-kompressory | 10740 |
| gazetapervomaisk.ru | kompressor-mehdvor | enger-air.ru/catalog/vintovye_kompressory | 5728 |
| gazetapetrovka.ru | kislorod-rybovodstvo | enger-air.ru/catalog/kislorodnye-ustanovki<br>enger-air.ru/catalog/kislorodnye-ustanovki/generator-kisloro | 7199 |
| info-svarka.ru | vozduh-dlya-plazmennoj-rezki | enger-air.ru/catalog/bezmaslyanye_kompressory | 8697 |
| kineshemec.ru | dizel-na-strojke | enger-air.ru/catalog/peredvizhnye-kompressory/dizelnye-kompr<br>prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/vint | 11761 |
| krasnodar.bz | azot-v-upakovke-produkcii | enger-air.ru/catalog/azotnye-ustanovki<br>crossair-compressor.ru/catalog/vintovye-kompressory | 9605 |
| kz24.news | azot-zernohranilishche | enger-air.ru/catalog/azotnye-ustanovki<br>enger-air.ru/catalog/azotnye-ustanovki/generatory_azota | 5429 |
| moscow-baku.ru | ks-dlya-promproekta | prokompressor.ru/catalog/kompressornye-stantsii-szhatogo-voz<br>zif-kompressor.ru/catalog | 10210 |
| new-sebastopol.com | vysokoe-davlenie-ispytaniya | prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/vint<br>prokompressor.ru/catalog/vozdushnye-kompressory/kompressory-<br>ac-kompressor.ru/catalog/dizelnye-kompressory-do-8-bar/dizel | 8666 |
| operativa.ru | vozduh-po-schetchiku | prokompressor.ru/services | 5741 |
| sakhapress.ru | skolko-stoit-szhatyj-vozduh | prokompressor.ru/services | 8263 |
| samaraonline24.ru | podbor-vintovogo | prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/vint | 6969 |

## Перед закупкой

Строку завести в PLACEMENTS-LOG.md - счёт ссылок на акцептор ведётся по журналу,
а не по памяти сессии. Публикация на площадке - только после подтверждения владельца.