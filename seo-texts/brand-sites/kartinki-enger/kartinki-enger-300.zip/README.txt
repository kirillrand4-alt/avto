Картинки категорий Enger, 300x300, прозрачный фон (PNG с альфой)

Компрессоры низкого давления
  файл:  kompressory-nizkogo-davleniya-enger.png
  alt:   Винтовой компрессор низкого давления Enger
  title: Компрессоры низкого давления Enger - купить у официального поставщика
  раздел: https://prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/nizkogo-davleniya/

Центробежные компрессоры
  файл:  centrobezhnye-kompressory-enger.png
  alt:   Центробежный турбокомпрессор Enger на раме
  title: Центробежные компрессоры Enger - подбор и поставка
  раздел: https://prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/tsentrobezhnye/

Передвижные компрессоры
  файл:  peredvizhnye-kompressory-enger.png
  alt:   Передвижной дизельный компрессор Enger на шасси
  title: Передвижные компрессоры Enger - купить с доставкой
  раздел: https://prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/vintovye/peredvizhnye/

Спиральные компрессоры
  файл:  spiralnye-kompressory-enger.png
  alt:   Спиральный безмасляный компрессор Enger
  title: Спиральные компрессоры Enger - безмасляное сжатие
  раздел: https://prokompressor.ru/catalog/vozdushnye-kompressory/po-tipu/spiralnye/

Как сделаны:
  Кадры - картиночная модель шлюза (gpt-image-2), палитра задана жёстко:
  графит RAL 7024 на раме, светло-серый RAL 7035 на панелях.
  Фон снят заливкой от краёв, край сглажен, пропорции не менялись.
  Знак ENGER настоящий, взят из каталога и с карточки Enger HB-37DT.
  Место под знак ищет программа: под ним не должно быть ни стыка, ни
  петли, ни болта, ни кабеля. Тёмный знак кладётся умножением, светлый
  осветлением - поэтому подхватывает освещение панели.

На центробежном знак одноярусный: машина широкая, самая большая плоская
площадка на ней - плита редуктора, и подпись вторым ярусом там нечитаема.